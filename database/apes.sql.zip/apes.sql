-- phpMyAdmin SQL Dump
-- version 5.1.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 10, 2022 at 02:42 PM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 7.4.29

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `apes`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `role` enum('full','simple') NOT NULL,
  `password` int(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `name`, `email`, `role`, `password`) VALUES
(2, 'Ndeko', 'ndeko@gmail.com', 'simple', 111111),
(3, 'tresor', 'tresor@gmail.com', 'simple', 111111),
(4, 'Aristote', 'aryaristote@gmail.com', 'full', 111111),
(5, 'Sylavanie Bachishoga', 'Sylavanie@gmail.com', 'simple', 0),
(6, 'Kalume Ernest Aristote', 'kalume@gmail.com', 'simple', 0),
(7, 'Kalume', 'aryaristote@gmail.com', 'simple', 0),
(8, 'Gloire Ndeko', 'kalume@gmail.com', 'simple', 0),
(9, 'Gloire Ndeko', 'kalume@gmail.com', 'simple', 111111),
(10, 'Sylavanie Bachishoga', 'gloire@gmail.com', 'simple', 0),
(11, 'arsene', 'arsene@gmail.com', 'simple', 111111),
(24, 'jsjwere', 'ary@gmail.com', 'full', 111111);

-- --------------------------------------------------------

--
-- Table structure for table `contact`
--

CREATE TABLE `contact` (
  `message_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `message` varchar(5000) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `contact`
--

INSERT INTO `contact` (`message_id`, `name`, `email`, `message`, `created_at`) VALUES
(9, 'Kalume Ernest Aristote', 'aryaristote@gmail.com', 'Nous vous permettons d\'envoyer des SMS avec un numéro ou un nom d\'expéditeur que vous définissez. Le SMS factice donne l\'impression d\'avoir été envoyé par l\'expéditeur que vous avez choisi. Faites des blagues à vos amis en leur envoyant un SMS factice, ils ne sauront jamais que c\'était vous.', '2022-08-10 12:17:07'),
(10, 'Gloire Masheka', 'Mashgloire@gmail.com', 'Nous voulons vous montrer à quel point c\'est facile d\'envoyer des SMS factices avec un faux numéro de téléphone. Il donne l\'impression d\'avoir été envoyé par l\'expéditeur que vous avez choisi. Faites attention ! Le SMS factice peut être à l\'origine de disputes et de conflits. N\'importe qui peut utiliser un numéro falsifié !', '2022-08-10 12:17:46'),
(11, 'JOhn Chishugi Iragi', 'Jkchishugi@icloud.com', 'Pour falsifier des SMS, vous avez besoin de codes. Il suffit d\'en acheter sur notre site internet. Entrez une adresse e-mail valide et un mot de passe. Le SMS factice vous sera envoyé immédiatement. Avec votre mot de passe, vous pouvez demander vos SMS factices à tout moment.', '2022-08-10 12:18:17'),
(12, 'Joel Nsazu', 'joesanzu@gmail.com', 'Vous pouvez choisir comme expéditeur n\'importe quel numéro ou nom. Il n\'y a pas de limite. Comme nous utilisons une numérotation internationale, il est possible d\'envoyer des SMS factices dans le monde entier. En général, vos SMS factices envoyés depuis un numéro de téléphone falsifié seront reçus quelques secondes après avoir été envoyés. Commencez à falsifier des SMS !', '2022-08-10 12:18:50'),
(13, 'Milton Kamandji', 'Mkamandji@gmail.com', 'Nous tenons à préciser : les utilisateurs sont responsables des conséquences engendrées par leur utilisation de notre service. Veuillez faire attention lorsque vous envoyez des SMS factices depuis des numéros falsifiés.', '2022-08-10 12:19:18'),
(14, 'Andy Mulago', 'andyMul23@gmail.com', 'Who hasn’t wanted to prank their friends or family? Who has never wanted to create a false message to deceive someone? But, do you know how to do it? Well, we bring you the best fake text message apps for Android; you can prank anyone with any of these apps. These apps will help you make fake text messages from WhatsApp, Facebook Messenger, Instagram, or any other messaging app. They will look so authentic that even the most astute person won’t know the difference!', '2022-08-10 12:22:04'),
(15, 'Katende Gedeon', 'GedeonKat@gmail.com', 'It is a fake texting app design to generate a message that you want, mainly to play a joke on someone you know. This app allows you to fake even entire conversations with a genuine tone; no one would think it is a fake chat! Fool your friends into believing that this person has been writing you those compromising messages all this time. Watch how amazed they are that you have a conversation with that well-known person they never thought you could have.', '2022-08-10 12:22:33');

-- --------------------------------------------------------

--
-- Table structure for table `news`
--

CREATE TABLE `news` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` varchar(1500) NOT NULL,
  `files_name` varchar(255) NOT NULL,
  `files_url` varchar(255) NOT NULL,
  `create_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `sponsors` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `news`
--

INSERT INTO `news` (`id`, `title`, `description`, `files_name`, `files_url`, `create_at`, `sponsors`) VALUES
(54, 'Really Neat CSS Cards For You To Use In Your Website', 'These card examples display beautifully on any kind of website or screen size. And, designers can add their custom elements to the CSS code snippets. So, it makes sense to use CSS cards in your projects.\r\nThe animation effect of this example is powerful. Each card has a shadow and transitions into a 4 edged shuriken-like shape. Some of the div class CSS properties used to create this template include:', '377e14cbb561c1d401f700a8261d5ab0.jpg', 'files/377e14cbb561c1d401f700a8261d5ab0.jpg', '0000-00-00 00:00:00', 'www.youtube.com'),
(55, 'What can I do to prevent this in the future?', 'If you are on a personal connection, like at home, you can run an anti-virus scan on your device to make sure it is not infected with malware.\r\n\r\nIf you are at an office or shared network, you can ask the network administrator to run a scan across the network looking for misconfigured or infected devices.\r\n\r\nAnother way to prevent getting this page in the future is to use Privacy Pass. Check out the browser extension in the Chrome Web Store.', '80e338430fcee0d371600929936bfa4c.jpg', 'files/80e338430fcee0d371600929936bfa4c.jpg', '0000-00-00 00:00:00', ' browser extension in the Chrome Web Store.');

-- --------------------------------------------------------

--
-- Table structure for table `offres`
--

CREATE TABLE `offres` (
  `offre_id` int(11) NOT NULL,
  `post_name` varchar(255) NOT NULL,
  `post_description` varchar(5000) NOT NULL,
  `post_exigence` varchar(5000) NOT NULL,
  `post_number` int(11) NOT NULL,
  `post_zone` varchar(255) NOT NULL,
  `start_date` date NOT NULL,
  `post_contract` enum('Stage','Enquete','Contrat') NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `offres`
--

INSERT INTO `offres` (`offre_id`, `post_name`, `post_description`, `post_exigence`, `post_number`, `post_zone`, `start_date`, `post_contract`, `created_at`) VALUES
(3, 'Manager Supply Chain', 'Sous la supervision du Field Coordinator, SC Manager a pour responsabilités principales d`organiser les achats des services et des biens, la gestion des inventaires et actifs de l`organisation, la logistique et renforce les capacités des staffs support dans le respect strict des procédures et politiques d’achats mises en place par IRC et ses bailleurs des fonds.', 'Le Supply Chain Manager a la charge de :\r\n• Superviser le gestionnaire des inventaires, il assure la sûreté et la sécurité des entrepôts, la gestion des actifs (maintenance, réparation, évaluation, ventes aux enchères et donations) et supervise la sélection du site d\'entrepôt suivant les règles du bailleur et les procédures d’IRC ;\r\n• En collaboration avec les programmes, Il (elle) approuve les stocks tampons, s`assure que la gestion du stockage des médicaments et les stocks CIK ainsi que les plans de distribution se fassent selon les procédures GSC en place ;\r\n• Avec le support du Directeur Adjoint en charge des opérations et du Coordinateur Supply Chain, il (elle) s`assure que la destruction des stocks expirés est faite selon les procédures d`élimination des stocks en place ;\r\n• Il (Elle) supervise le comptage cyclique des inventaires et coordonne le processus de réconciliation avec les équipes d’inventaires ;\r\n• Il (elle) revoie et approuve tous les rapports de comptage avant une transmission auprès de son superviseur et justifie les écarts des comptages, le cas échéant ;\r\n• Il (elle) s`assure que tous les actifs sont couverts par une assurance valide.', 1, 'Bukavu, Kavumu', '2022-02-12', 'Enquete', '2022-07-29 18:15:47'),
(4, 'EMPLOYE ADMINISTRATIF', 'EMPLOYE ADMINISTRATIF DANS UNE SOCIETE MINIERE A KINDU, PROVINCE DU MANIEMA, EN REPUBLIQUE DEMOCRATIQUE DU CONGO Société\r\nspécialisée dans l\'exploration et l\'exploitation minière,\r\nà Kindu, Province du Maniema, en République Démocratique du Congo.', 'Un minimum de 5 années d\'expérience dans une fonction similaire\r\n- Une personne\r\ndynamique disposant d’une excellente capacité d’écoute et de\r\ncommunication\r\nPouvoir fonctionner en équipe\r\nPersonnalité agréable, dévouée et honnête\r\nUne expérience en Afrique est indispensable', 1, 'Kindu, Kasumbalesa', '2021-04-14', 'Stage', '2022-07-29 18:18:36'),
(5, 'Consultant: rédaction et analyse des données de l’évaluation de base', 'Cette étude poursuit cinq principaux objectifs:\r\n• Analyser le contexte actuel de la gouvernance, notamment autour de l’accès à un espace civique pour les groupes marginalisés, touchés par l’insécurité et les violations des droits de l’homme à l’Est de la RDC (Nord-Kivu, Sud-Kivu et Tanganyika) ;\r\n• Renseigner sur la situation de départ par rapport aux valeurs de base des indicateurs du projet ;\r\n• Renseigner sur la pertinence de la théorie de changement par rapport à la logique d’intervention du projet ;\r\n• Analyser l’interaction entre la dynamique contextuelle/conflictuelle et le programme afin de concevoir un programme sensible aux conflits, en proposant une stratégie de recommandation, pour s\'assurer le respect du principe de «Ne pas nuire» et la sensibilité aux conflits ;\r\n• Renseigner le projet sur les habitudes des populations locales sur l\'utilisation des médias dans les zones d’intervention du projet.\r\n', 'All Search Employees must adhere to the values: Collaboration- Audacity - Tenacity - Empathy - Results. In accordance with these values, Search enforces compliance with the Code of Conduct and related policies on Anti Workplace Harassment, Protection from Exploitation and Abuse, Child Safeguarding, Conflict of Interest and Anti-fraud. Search is committed to safeguarding the interests, rights, and well-being of children, youth and vulnerable adults with whom it is in contact and to conducting its programs and operations in a manner that is safe for children, youth, and vulnerable adults.\r\n\r\nSearch for Common Ground does not and shall not discriminate on the basis of race, color, religion (creed), gender, gender expression, age, national origin (ancestry), disability, marital status, sexual orientation, or military status, in any of its activities or operations.', 4, 'Goma', '2012-02-21', 'Contrat', '2022-07-29 18:19:56'),
(6, 'Consultant: rédaction et analyse des données de l’évaluation de base', 'Cette étude poursuit cinq principaux objectifs:\r\n• Analyser le contexte actuel de la gouvernance, notamment autour de l’accès à un espace civique pour les groupes marginalisés, touchés par l’insécurité et les violations des droits de l’homme à l’Est de la RDC (Nord-Kivu, Sud-Kivu et Tanganyika) ;\r\n• Renseigner sur la situation de départ par rapport aux valeurs de base des indicateurs du projet ;\r\n• Renseigner sur la pertinence de la théorie de changement par rapport à la logique d’intervention du projet ;\r\n• Analyser l’interaction entre la dynamique contextuelle/conflictuelle et le programme afin de concevoir un programme sensible aux conflits, en proposant une stratégie de recommandation, pour s\'assurer le respect du principe de «Ne pas nuire» et la sensibilité aux conflits ;\r\n• Renseigner le projet sur les habitudes des populations locales sur l\'utilisation des médias dans les zones d’intervention du projet.\r\n', 'All Search Employees must adhere to the values: Collaboration- Audacity - Tenacity - Empathy - Results. In accordance with these values, Search enforces compliance with the Code of Conduct and related policies on Anti Workplace Harassment, Protection from Exploitation and Abuse, Child Safeguarding, Conflict of Interest and Anti-fraud. Search is committed to safeguarding the interests, rights, and well-being of children, youth and vulnerable adults with whom it is in contact and to conducting its programs and operations in a manner that is safe for children, youth, and vulnerable adults.\r\n\r\nSearch for Common Ground does not and shall not discriminate on the basis of race, color, religion (creed), gender, gender expression, age, national origin (ancestry), disability, marital status, sexual orientation, or military status, in any of its activities or operations.', 4, 'Goma', '2012-02-21', 'Contrat', '2022-07-29 18:20:33'),
(7, 'Consultant: rédaction et analyse des données de l’évaluation de base', 'Cette étude poursuit cinq principaux objectifs:\r\n• Analyser le contexte actuel de la gouvernance, notamment autour de l’accès à un espace civique pour les groupes marginalisés, touchés par l’insécurité et les violations des droits de l’homme à l’Est de la RDC (Nord-Kivu, Sud-Kivu et Tanganyika) ;\r\n• Renseigner sur la situation de départ par rapport aux valeurs de base des indicateurs du projet ;\r\n• Renseigner sur la pertinence de la théorie de changement par rapport à la logique d’intervention du projet ;\r\n• Analyser l’interaction entre la dynamique contextuelle/conflictuelle et le programme afin de concevoir un programme sensible aux conflits, en proposant une stratégie de recommandation, pour s\'assurer le respect du principe de «Ne pas nuire» et la sensibilité aux conflits ;\r\n• Renseigner le projet sur les habitudes des populations locales sur l\'utilisation des médias dans les zones d’intervention du projet.\r\n', 'All Search Employees must adhere to the values: Collaboration- Audacity - Tenacity - Empathy - Results. In accordance with these values, Search enforces compliance with the Code of Conduct and related policies on Anti Workplace Harassment, Protection from Exploitation and Abuse, Child Safeguarding, Conflict of Interest and Anti-fraud. Search is committed to safeguarding the interests, rights, and well-being of children, youth and vulnerable adults with whom it is in contact and to conducting its programs and operations in a manner that is safe for children, youth, and vulnerable adults.\r\n\r\nSearch for Common Ground does not and shall not discriminate on the basis of race, color, religion (creed), gender, gender expression, age, national origin (ancestry), disability, marital status, sexual orientation, or military status, in any of its activities or operations.', 4, 'Goma', '2012-02-21', 'Contrat', '2022-07-29 18:20:34'),
(8, 'Consultant: rédaction et analyse des données de l’évaluation de base', 'Cette étude poursuit cinq principaux objectifs:\r\n• Analyser le contexte actuel de la gouvernance, notamment autour de l’accès à un espace civique pour les groupes marginalisés, touchés par l’insécurité et les violations des droits de l’homme à l’Est de la RDC (Nord-Kivu, Sud-Kivu et Tanganyika) ;\r\n• Renseigner sur la situation de départ par rapport aux valeurs de base des indicateurs du projet ;\r\n• Renseigner sur la pertinence de la théorie de changement par rapport à la logique d’intervention du projet ;\r\n• Analyser l’interaction entre la dynamique contextuelle/conflictuelle et le programme afin de concevoir un programme sensible aux conflits, en proposant une stratégie de recommandation, pour s\'assurer le respect du principe de «Ne pas nuire» et la sensibilité aux conflits ;\r\n• Renseigner le projet sur les habitudes des populations locales sur l\'utilisation des médias dans les zones d’intervention du projet.\r\n', 'All Search Employees must adhere to the values: Collaboration- Audacity - Tenacity - Empathy - Results. In accordance with these values, Search enforces compliance with the Code of Conduct and related policies on Anti Workplace Harassment, Protection from Exploitation and Abuse, Child Safeguarding, Conflict of Interest and Anti-fraud. Search is committed to safeguarding the interests, rights, and well-being of children, youth and vulnerable adults with whom it is in contact and to conducting its programs and operations in a manner that is safe for children, youth, and vulnerable adults.\r\n\r\nSearch for Common Ground does not and shall not discriminate on the basis of race, color, religion (creed), gender, gender expression, age, national origin (ancestry), disability, marital status, sexual orientation, or military status, in any of its activities or operations.', 4, 'Goma', '2012-02-21', 'Contrat', '2022-07-29 18:20:35');

-- --------------------------------------------------------

--
-- Table structure for table `project`
--

CREATE TABLE `project` (
  `project_id` int(11) NOT NULL,
  `project_name` varchar(2000) NOT NULL,
  `project_content` varchar(5000) NOT NULL,
  `project_zone` varchar(500) NOT NULL,
  `project_sponsor` varchar(500) NOT NULL,
  `project_status` enum('En cours','Finis') NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `files_name` varchar(255) NOT NULL,
  `files_url` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `project`
--

INSERT INTO `project` (`project_id`, `project_name`, `project_content`, `project_zone`, `project_sponsor`, `project_status`, `created_at`, `files_name`, `files_url`) VALUES
(7, 'PRÉVENTION DE L’ASSOCIATION D’ENFANTS AUX GROUPES ARMÉS,', 'Les filles et et femmes survivantes des violences sexuelle et basée sur le genre, la discrimination à l’égard de peuples autochtones, ont reçu de fond de démarrage pour leurs AGR, en plus la capacitation sur l’entrepreneuriat locale Projet Unicef et WCH.', 'Numbi, Zirala, Minova et Kalonge, 2019 - 2020', 'WarChild Holland & UNICEF', 'Finis', '2022-07-27 14:30:12', 'worlchild.JPEG', 'files/worlchild.JPEG'),
(8, 'AUTONOMISATION DES FEMMES ET FILLES', 'Projet d\'autonomisation des femmes et filles à travers l\'agriculture dans l\'approche Framing for life.', 'Uvira, Kalehe, Kabare, 2016 - 2017', 'DMCCD Danemark', 'Finis', '2022-07-27 14:31:11', 'dmccd.JPEG', 'files/dmccd.JPEG'),
(9, 'RÉALISATION DES ACTIVITÉS DE RÉINSERTION ÉCONOMIQUE,', 'Les filles et et femmes survivantes des violences sexuelle et basée sur le genre, la discrimination à l’égard de peuples autochtones, ont reçu de fond de démarrage pour leurs AGR, en plus la capacitation sur l’entrepreneuriat locale.', 'MInova, 2015 - 2018', 'PNUD- Program. TUPINGE UBAKAJI / CANADA', 'Finis', '2022-07-27 14:33:06', 'tupingeUbakadji.JPEG', 'files/tupingeUbakadji.JPEG'),
(10, 'APPUI AU RENFORCEMENT DE LA COHÉSION SOCIALE,', 'Projet d\'appui au renforcement de la cohésion sociale par l\'installation/équipement de deux radios communautaires et le renforcement /création des structures locales de gestion des conflits dans les groupements de Kashenyi/Kamanyola et d\'Itara-Luvungi au Sud-Kivu.', 'Kamanyola, Luvingu, 2017 - 2018', 'PNUD/Japon, Programme Cohésion Sociale', 'Finis', '2022-07-27 14:34:11', 'pnud_japon.JPEG', 'files/pnud_japon.JPEG'),
(11, 'APPUI À LA RÉINSERTION SOCIOÉCONOMIQUE DES SURVIVANTES DES VIOLENCES', 'Projet d’appui à la réinsertion socioéconomique des survivantes des violences basées sur le genre et autonomisation des femmes dans la ville de Bukavu et à Kamituga dans la province du Sud-Kivu, RD Congo.', 'Bukavu, 2018 - 2019', 'PNUD- Programme JAD 2', 'Finis', '2022-07-27 14:37:28', 'jad2.jpeg', 'files/jad2.jpeg'),
(12, 'LA CONSOLIDATION ET PÉRENNISATION DES ACTIVITÉS DE RÉINSERTION SOCIOÉCONOMIQUE,', 'Appui à la consolidation et pérennisation des activités de réinsertion socioéconomique et rescolarisation des survivantes des VSBG à Bukavu, Walungu et Kamituga dans la province du Sud Kivu.', 'Bukavu, Walungu, Kamituga, 2020 - 2021', 'PNUD- Programme JAD', 'Finis', '2022-07-27 14:39:21', 'jad.jpeg', 'files/jad.jpeg'),
(13, 'PROJET PNUD, COVID-19', 'RPA: CMA/RPP-COV/2020-15 Projet de Mise en œuvre des activités du programme de soutien à la coordination provinciale de la réponse multisectorielle COVID-19, au maintien des activités économiques et à la production locale de moyens de protection contre le COVID-19 au Sud-Kivu.', 'Bukavu, Sept.2020 - Dec.2020', 'PNUD', 'Finis', '2022-07-27 14:40:05', 'pnud_covid19.jpeg', 'files/pnud_covid19.jpeg'),
(14, 'EDC (EDUCATION DEVELOPMENT CENTER), PROJET D\'ÉDUCATION', 'Activités de USAID pour le développement des intégrés des jeunes dans le territoire de Kalehe au dans les province du sud-Kivu à pris 500 jeunes filles et garçons désœuvrés et de peuples autochtones, analphabètes pour une alphabétisation appuyée par les curricula de développement personnel et d’entrepreneuriat (work ready now, be your only boss, work base landing) initiation aux activités des micro finance( approche SILC, save and internal landing community) boucler par une remise de kit BYOB comme appui socio-économique et t’élancèrent de micro entreprise de 500 jeunes.', 'Kalehe Ihusi, Nybibwe, Minova, Numbi, Ziralo, Bundje, Kalonge et Bunyakiri, 2020 - 2021', 'Projet ADIJ', 'Finis', '2022-07-27 14:41:10', 'edc.jpeg', 'files/edc.jpeg'),
(15, 'ELIMU NI JIBU', 'Vice l’accès et la qualité à l’éducation de jeunes filles et garçons dans le territoire de MWENGA, qu’ils soient doué et compétitif. Ce projet organise des programme de tutorat dans les écoles étatiques et conventionnée, pour relever le niveau des élèves ayant de lacune en lecture-écriture et calculs, a noté la lutte contre toute forme des violences en milieu scolaire en mettant en place des comité genre et surveillance des toute formes des violences en milieu scolaire et dans la communauté, promouvoir le leadership féminin par l’approche GLOW (Girls Lead Our World).', 'Mwenga, 2021 à aujourd’hui,', 'USAID', 'En cours', '2022-07-27 14:41:57', 'fhi360.jpeg', 'files/fhi360.jpeg');

-- --------------------------------------------------------

--
-- Table structure for table `visitors`
--

CREATE TABLE `visitors` (
  `id` int(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `country` varchar(255) NOT NULL,
  `location` varchar(255) NOT NULL,
  `domain` varchar(255) NOT NULL,
  `phone` varchar(255) NOT NULL,
  `niveau` enum('Diplome','Grade','Licence','Master','Plus') NOT NULL,
  `experience` varchar(255) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `files_name` varchar(255) NOT NULL,
  `files_url` varchar(255) NOT NULL,
  `files_name2` varchar(255) NOT NULL,
  `files_url2` varchar(255) NOT NULL,
  `files_name3` varchar(255) NOT NULL,
  `files_url3` varchar(255) NOT NULL,
  `applied_offer` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `visitors`
--

INSERT INTO `visitors` (`id`, `name`, `country`, `location`, `domain`, `phone`, `niveau`, `experience`, `created_at`, `files_name`, `files_url`, `files_name2`, `files_url2`, `files_name3`, `files_url3`, `applied_offer`) VALUES
(20, 'Kalume Ernest Aristote', 'Congolaise', 'Rwanda', 'FInance Admini', '0', 'Licence', '4', '2022-07-22 21:51:27', 'KALUME ERNEST Aristote\'CV.pdf', 'files/KALUME ERNEST Aristote\'CV.pdf', '', '', '', '', ''),
(21, 'Kalume Ernest Aristote', 'Congolaise', 'Kinshasa', 'FInance Admini', '0', 'Licence', '4', '2022-07-22 21:56:04', 'KALUME ERNEST Aristote\'CV.pdf', 'files/KALUME ERNEST Aristote\'CV.pdf', 'Josh CV Fr.pdf', 'files/Josh CV Fr.pdf', '', '', ''),
(22, 'Kalume Ernest Aristote', 'Congolaise', 'Rwanda', 'Computer Science', '0', 'Grade', '4', '2022-07-22 22:02:51', 'caninical.docx.pdf', 'files/caninical.docx.pdf', 'Josh CV Fr.pdf', 'files/Josh CV Fr.pdf', 'KALUME ERNEST Aristote\'CV.pdf', 'files/KALUME ERNEST Aristote\'CV.pdf', ''),
(23, 'Kalume Ernest Aristote', 'Congolaise', 'Rwanda', 'Computer Science', '0', 'Grade', '4', '2022-07-22 22:03:05', 'caninical.docx.pdf', 'files/caninical.docx.pdf', 'Josh CV Fr.pdf', 'files/Josh CV Fr.pdf', 'KALUME ERNEST Aristote\'CV.pdf', 'files/KALUME ERNEST Aristote\'CV.pdf', ''),
(24, 'Kalume Ernest Aristote', 'Congolaise', 'Rwanda', 'Computer Science', '0', 'Grade', '4', '2022-07-22 22:03:07', 'caninical.docx.pdf', 'files/caninical.docx.pdf', 'Josh CV Fr.pdf', 'files/Josh CV Fr.pdf', 'KALUME ERNEST Aristote\'CV.pdf', 'files/KALUME ERNEST Aristote\'CV.pdf', ''),
(25, 'Kalume Ernest Aristote', 'Congolaise', 'Rwanda', 'Computer Science', '0', 'Grade', '4', '2022-07-22 22:03:08', 'caninical.docx.pdf', 'files/caninical.docx.pdf', 'Josh CV Fr.pdf', 'files/Josh CV Fr.pdf', 'KALUME ERNEST Aristote\'CV.pdf', 'files/KALUME ERNEST Aristote\'CV.pdf', ''),
(26, 'Kalume Ernest Aristote', 'Congolaise', 'Rwanda', 'Computer Science', '0', 'Grade', '4', '2022-07-22 22:03:09', 'caninical.docx.pdf', 'files/caninical.docx.pdf', 'Josh CV Fr.pdf', 'files/Josh CV Fr.pdf', 'KALUME ERNEST Aristote\'CV.pdf', 'files/KALUME ERNEST Aristote\'CV.pdf', ''),
(27, 'Kalume Ernest Aristote', 'Congolaise', 'Rwanda', 'Computer Science', '0', 'Grade', '4', '2022-07-22 22:03:10', 'caninical.docx.pdf', 'files/caninical.docx.pdf', 'Josh CV Fr.pdf', 'files/Josh CV Fr.pdf', 'KALUME ERNEST Aristote\'CV.pdf', 'files/KALUME ERNEST Aristote\'CV.pdf', ''),
(28, 'Kalume Ernest Aristote', 'Congolaise', 'Kinshasa', 'Computer Science', '0', 'Master', '4', '2022-07-24 04:48:08', 'KALUME ERNEST Aristote\'CV.pdf', 'files/KALUME ERNEST Aristote\'CV.pdf', 'Josh CV Fr.pdf', 'files/Josh CV Fr.pdf', 'caninical.docx.pdf', 'files/caninical.docx.pdf', ''),
(29, 'Ndeko Ernest Aristote', 'Congolaise', 'dedscsdfds', 'Love is bae', '0', 'Grade', '3', '2022-07-24 16:20:59', 'Motivation letter.pdf', 'files/Motivation letter.pdf', 'Resume John CHISHUGI.pdf', 'files/Resume John CHISHUGI.pdf', 'word-template-cv.pdf', 'files/word-template-cv.pdf', ''),
(31, 'Kalume Ernest Aristote', 'Congolais', 'Goma', 'COmputer Science', '0', 'Licence', '4', '2022-07-25 12:53:10', 'KALUME ERNEST Aristote\'CV.pdf', 'files/KALUME ERNEST Aristote\'CV.pdf', 'Josh CV Fr.pdf', 'files/Josh CV Fr.pdf', 'caninical.docx.pdf', 'files/caninical.docx.pdf', ''),
(32, 'Rita Mudumbu Bora', 'Congolais', 'Goma', 'COmputer Science', '0', 'Diplome', '3', '2022-07-25 13:13:12', 'caninical.docx.pdf', 'admin/files/caninical.docx.pdf', 'Josh CV Fr.pdf', 'admin/files/Josh CV Fr.pdf', 'KALUME ERNEST Aristote\'CV.pdf', 'admin/files/KALUME ERNEST Aristote\'CV.pdf', ''),
(33, 'Ndeko Goire', 'congolaise', 'BUkavu', 'Finance et comptabiite', '0', 'Licence', '3', '2022-07-25 13:14:49', 'caninical.docx.pdf', 'admin/files/caninical.docx.pdf', 'Josh CV Fr.pdf', 'admin/files/Josh CV Fr.pdf', 'KALUME ERNEST Aristote\'CV.pdf', 'admin/files/KALUME ERNEST Aristote\'CV.pdf', ''),
(34, 'Ndeko Goire', 'congolaise', 'BUkavu', 'Finance et comptabiite', '0', 'Licence', '3', '2022-07-25 16:54:59', 'caninical.docx.pdf', 'admin/files/caninical.docx.pdf', 'Josh CV Fr.pdf', 'admin/files/Josh CV Fr.pdf', 'KALUME ERNEST Aristote\'CV.pdf', 'admin/files/KALUME ERNEST Aristote\'CV.pdf', ''),
(35, 'Teste', 'Teste', 'Teste', 'Teste', '990', 'Grade', '2', '2022-07-29 22:56:47', '9543cfb7f3ac0ee4c1b6caba00a81acb.pdf', 'admin/files/9543cfb7f3ac0ee4c1b6caba00a81acb.pdf', 'f220b3f837325c7ae195b0895e49a469.pdf', 'admin/files/f220b3f837325c7ae195b0895e49a469.pdf', '3a9f64e25eb378f4c8a9127c4494873b.pdf', 'admin/files/3a9f64e25eb378f4c8a9127c4494873b.pdf', ''),
(36, 'Teste', 'Teste', 'Teste', 'Teste', '990', 'Grade', '2', '2022-07-29 22:58:52', '63f755bb88759aefca79ee080ea6053a.pdf', 'admin/files/63f755bb88759aefca79ee080ea6053a.pdf', 'd203148fc32599e507f9e6023286b78f.pdf', 'admin/files/d203148fc32599e507f9e6023286b78f.pdf', 'af83c223ad975cbbebdf993f0c23597a.pdf', 'admin/files/af83c223ad975cbbebdf993f0c23597a.pdf', ''),
(37, 'Teste', 'Teste', 'Teste', 'Teste', '990', 'Grade', '2', '2022-07-29 22:59:17', '4aec59a2996d20598850b05987060a69.pdf', 'admin/files/4aec59a2996d20598850b05987060a69.pdf', 'cd6de3cae697b8908bc7d3d5d057ec80.pdf', 'admin/files/cd6de3cae697b8908bc7d3d5d057ec80.pdf', 'f3f7ab7bbee77dde4163b941757da6b3.pdf', 'admin/files/f3f7ab7bbee77dde4163b941757da6b3.pdf', ''),
(38, 'Teste', 'Teste', 'Teste', 'Teste', '990', 'Grade', '2', '2022-07-29 23:01:34', '12a838c0bc621836d6fb0f95cfeae876.pdf', 'admin/files/12a838c0bc621836d6fb0f95cfeae876.pdf', '39d53ce30afd258e40d70d9607b17f26.pdf', 'admin/files/39d53ce30afd258e40d70d9607b17f26.pdf', '11562c478b5657666ffdb232edd76f47.pdf', 'admin/files/11562c478b5657666ffdb232edd76f47.pdf', ''),
(39, 'Teste', 'Teste', 'Teste', 'Pedagogie Generale', '990', 'Diplome', '1', '2022-07-29 23:02:50', '8cae636b12ae9048a9b8625589178f78.pdf', 'admin/files/8cae636b12ae9048a9b8625589178f78.pdf', 'e8d941420626dffffa5a4b657ecfdf65.pdf', 'admin/files/e8d941420626dffffa5a4b657ecfdf65.pdf', '62c74afbc23e7a91b09300b10e67a8d4.pdf', 'admin/files/62c74afbc23e7a91b09300b10e67a8d4.pdf', ''),
(40, 'Teste', 'Teste', 'Teste', 'Pedagogie Generale', '0990-413-132', 'Diplome', '1', '2022-07-29 23:03:59', '369c5d0e7e139034f2483c3cf4cd097b.pdf', 'admin/files/369c5d0e7e139034f2483c3cf4cd097b.pdf', '1283344cf7a2bcb1109487533fb7aece.pdf', 'admin/files/1283344cf7a2bcb1109487533fb7aece.pdf', 'd3e96d3ce138d43010162bb551824712.pdf', 'admin/files/d3e96d3ce138d43010162bb551824712.pdf', ''),
(41, 'Teste', 'Teste', 'Teste', 'Pedagogie Generale', '0990 413 132', 'Diplome', '1', '2022-07-29 23:34:59', '703ed3046c0a56ab098b24e5e6e2a64a.pdf', 'admin/files/703ed3046c0a56ab098b24e5e6e2a64a.pdf', 'c3ea65f5cb50ff067e7578783c6b3f9c.pdf', 'admin/files/c3ea65f5cb50ff067e7578783c6b3f9c.pdf', '93b6b0a8d577db4c24944a4b89cc2665.pdf', 'admin/files/93b6b0a8d577db4c24944a4b89cc2665.pdf', 'Manager Supply Chain'),
(42, 'Teste', 'Teste', 'Teste', 'Pedagogie Generale', '0990 413 132', 'Diplome', '1', '2022-07-29 23:41:05', 'a6e1d81c65c6659790dedd4527d71412.pdf', 'admin/files/a6e1d81c65c6659790dedd4527d71412.pdf', '811c9a41ea3283cab56aa880dcf59e9b.pdf', 'admin/files/811c9a41ea3283cab56aa880dcf59e9b.pdf', 'd3d9d905f65fbf09b964179330f94936.pdf', 'admin/files/d3d9d905f65fbf09b964179330f94936.pdf', 'Manager Supply Chain'),
(43, 'Teste', 'Teste', 'Teste', 'Pedagogie Generale', '0990 413 132', 'Diplome', '1', '2022-07-29 23:41:20', 'a0ddea785a5a4ab18e03c398a9ec7b83.pdf', 'admin/files/a0ddea785a5a4ab18e03c398a9ec7b83.pdf', '9e44eb3ab0c9a4d7914a40d5a9b70581.pdf', 'admin/files/9e44eb3ab0c9a4d7914a40d5a9b70581.pdf', 'b81a9e27feac597cb7b87aedc9db00e7.pdf', 'admin/files/b81a9e27feac597cb7b87aedc9db00e7.pdf', 'Manager Supply Chain'),
(44, 'Teste', 'Teste', 'Teste', 'Pedagogie Generale', '0990 413 132', 'Diplome', '1', '2022-07-29 23:41:23', 'e8d029a8574e5a5f0ff63aca4abc3e59.pdf', 'admin/files/e8d029a8574e5a5f0ff63aca4abc3e59.pdf', '77094bcb6b6f3e3a2e639ca2b821112d.pdf', 'admin/files/77094bcb6b6f3e3a2e639ca2b821112d.pdf', '808541c85071cc3d33d5b31968fe92f8.pdf', 'admin/files/808541c85071cc3d33d5b31968fe92f8.pdf', 'Manager Supply Chain'),
(45, 'Teste', 'Teste', 'Teste', 'Pedagogie Generale', '0990 413 132', 'Diplome', '1', '2022-07-29 23:42:43', '44fd1176ac6e2cb71ebde8c8411572fb.pdf', 'admin/files/44fd1176ac6e2cb71ebde8c8411572fb.pdf', '765ca000ed9a8ad8ef7476373063f55e.pdf', 'admin/files/765ca000ed9a8ad8ef7476373063f55e.pdf', '7789b5021f63aa2b078eb00bd7e6ecee.pdf', 'admin/files/7789b5021f63aa2b078eb00bd7e6ecee.pdf', 'Manager Supply Chain'),
(46, 'Kalume Ernest Aristote', 'Kalume Ernest Aristote', 'Kalume Ernest Aristote', 'COmputer Science', '0990 413 132', 'Licence', '1', '2022-07-29 23:50:24', 'a48feacb63cdcd75ff5262b696727a2c.pdf', 'admin/files/a48feacb63cdcd75ff5262b696727a2c.pdf', 'f5140f83cfa2a52d7564f32ffc37f1be.pdf', 'admin/files/f5140f83cfa2a52d7564f32ffc37f1be.pdf', 'a86f8eda9032deaae6fbbc7785177b8f.pdf', 'admin/files/a86f8eda9032deaae6fbbc7785177b8f.pdf', 'EMPLOYE ADMINISTRATIF'),
(47, 'Kalume Ernest Aristote', 'ss', 'd', 'wq', '0990 413 132', 'Licence', '1', '2022-07-29 23:52:28', 'b16ef98cd718122f0a27b3af856d0c68.pdf', 'admin/files/b16ef98cd718122f0a27b3af856d0c68.pdf', 'c6ec9f6b3b5429ef9f44e3d177446580.pdf', 'admin/files/c6ec9f6b3b5429ef9f44e3d177446580.pdf', '642d38f96856be7a9a5f5309085d6542.pdf', 'admin/files/642d38f96856be7a9a5f5309085d6542.pdf', 'EMPLOYE ADMINISTRATIF'),
(48, 'Kalume Ernest Aristote', 'ss', 'd', 'wq', '0990 413 132', 'Licence', '1', '2022-07-29 23:58:08', '5b659d1d0759ad45800107397ea10f15.pdf', 'admin/files/5b659d1d0759ad45800107397ea10f15.pdf', '0e0c45ff30c712b4a9ecc8b487c1b4e8.pdf', 'admin/files/0e0c45ff30c712b4a9ecc8b487c1b4e8.pdf', 'ca28e6d2d1860ef5fc3213bfe336dca7.pdf', 'admin/files/ca28e6d2d1860ef5fc3213bfe336dca7.pdf', 'EMPLOYE ADMINISTRATIF'),
(49, 'Kalume Ernest Aristote', 'Teste', 'Goma', 'Teste', '0990 413 132', 'Licence', '1', '2022-07-29 23:58:56', '48ea49407a8bf018ee20ff3600b795b7.pdf', 'admin/files/48ea49407a8bf018ee20ff3600b795b7.pdf', 'fc1b7a40c14508cc246262bb7acaeabb.pdf', 'admin/files/fc1b7a40c14508cc246262bb7acaeabb.pdf', '0a9cf3ec84c5ebc2275a3de04776e458.pdf', 'admin/files/0a9cf3ec84c5ebc2275a3de04776e458.pdf', 'EMPLOYE ADMINISTRATIF'),
(50, 'Kalume Ernest Aristote', 'Teste', 'Goma', 'Teste', '0990 413 132', 'Licence', '1', '2022-07-29 23:59:34', '79c14f6001b25c01a5e9ec18caf5085e.pdf', 'admin/files/79c14f6001b25c01a5e9ec18caf5085e.pdf', '282bf04ce416999d36016745fdd50857.pdf', 'admin/files/282bf04ce416999d36016745fdd50857.pdf', '1b9d8cb8f61f5fc16b40f9a145104179.pdf', 'admin/files/1b9d8cb8f61f5fc16b40f9a145104179.pdf', 'EMPLOYE ADMINISTRATIF'),
(51, 'Kalume Ernest Aristote', 'Teste', 'Goma', 'Teste', '0990 413 132', 'Licence', '1', '2022-07-30 00:00:37', 'f090aa80f73bbae193a509b550f230b3.pdf', 'admin/files/f090aa80f73bbae193a509b550f230b3.pdf', '75599847b157a9b46c61009fe8c85b12.pdf', 'admin/files/75599847b157a9b46c61009fe8c85b12.pdf', '73be36d8fd66fa03966f93fcaaf85f31.pdf', 'admin/files/73be36d8fd66fa03966f93fcaaf85f31.pdf', 'EMPLOYE ADMINISTRATIF'),
(52, 'Kalume Ernest Aristote', 'Teste', 'Goma', 'Teste', '0990 413 132', 'Licence', '1', '2022-07-30 00:00:53', '43ebf4811774348303963bd4eb62dffe.pdf', 'admin/files/43ebf4811774348303963bd4eb62dffe.pdf', '78f7379de30cfbd60d255daeb14eb4ae.pdf', 'admin/files/78f7379de30cfbd60d255daeb14eb4ae.pdf', 'ca97a5b7d9cc283186acf8a4580a7193.pdf', 'admin/files/ca97a5b7d9cc283186acf8a4580a7193.pdf', 'EMPLOYE ADMINISTRATIF'),
(53, 'Kalume Ernest Aristote', 'Teste', 'Goma', 'Teste', '0990 413 132', 'Licence', '1', '2022-07-30 00:02:07', 'bc03b9a0729b09084213d062a1fc2d27.pdf', 'admin/files/bc03b9a0729b09084213d062a1fc2d27.pdf', '60b3e3744740c96aff0632b936a6633c.pdf', 'admin/files/60b3e3744740c96aff0632b936a6633c.pdf', '0aaa706c94c0df1e61f18efea661ab87.pdf', 'admin/files/0aaa706c94c0df1e61f18efea661ab87.pdf', 'EMPLOYE ADMINISTRATIF'),
(54, 'Kalume Ernest Aristote', 'Teste', 'Goma', 'Teste', '0990 413 132', 'Licence', '1', '2022-07-30 00:03:02', '42e007ba75f820a2b40a750aacaa29de.pdf', 'admin/files/42e007ba75f820a2b40a750aacaa29de.pdf', '0b750aa560b9be1b9c0ef613d0fd51a3.pdf', 'admin/files/0b750aa560b9be1b9c0ef613d0fd51a3.pdf', 'd3b97713318709adceb1159835b24ed7.pdf', 'admin/files/d3b97713318709adceb1159835b24ed7.pdf', 'EMPLOYE ADMINISTRATIF'),
(55, 'Kalume Ernest Aristote', 'Teste', 'Kavumu', 'Finance et comptabiite', '0990 413 132', 'Grade', '1', '2022-08-01 11:41:33', '2f39f0d98c4889adfe6d32c6a89b66c3.pdf', 'admin/files/2f39f0d98c4889adfe6d32c6a89b66c3.pdf', '2da18b613b727a09bd4af2fc333fffe9.pdf', 'admin/files/2da18b613b727a09bd4af2fc333fffe9.pdf', '159e2b3245be8e8fbc91622b3e7004e0.pdf', 'admin/files/159e2b3245be8e8fbc91622b3e7004e0.pdf', 'Consultant: rédaction et analyse des données de l’évaluation de base'),
(56, 'Kalume Ernest Aristote', 'Teste', 'Rwanda', 'Pedagogie Generale', '0990 413 132', 'Diplome', '1', '2022-08-01 11:42:35', 'f218c9b24fcb0c275ac6e25bdbc57731.pdf', 'admin/files/f218c9b24fcb0c275ac6e25bdbc57731.pdf', '96fc85a3a2bcf883819e4e686a980029.pdf', 'admin/files/96fc85a3a2bcf883819e4e686a980029.pdf', 'b852ddadb9e30bbca81b63c3bbc867f5.pdf', 'admin/files/b852ddadb9e30bbca81b63c3bbc867f5.pdf', 'EMPLOYE ADMINISTRATIF');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `contact`
--
ALTER TABLE `contact`
  ADD PRIMARY KEY (`message_id`);

--
-- Indexes for table `news`
--
ALTER TABLE `news`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `offres`
--
ALTER TABLE `offres`
  ADD PRIMARY KEY (`offre_id`);

--
-- Indexes for table `project`
--
ALTER TABLE `project`
  ADD PRIMARY KEY (`project_id`);

--
-- Indexes for table `visitors`
--
ALTER TABLE `visitors`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- AUTO_INCREMENT for table `contact`
--
ALTER TABLE `contact`
  MODIFY `message_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `news`
--
ALTER TABLE `news`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=58;

--
-- AUTO_INCREMENT for table `offres`
--
ALTER TABLE `offres`
  MODIFY `offre_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `project`
--
ALTER TABLE `project`
  MODIFY `project_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `visitors`
--
ALTER TABLE `visitors`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=57;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
